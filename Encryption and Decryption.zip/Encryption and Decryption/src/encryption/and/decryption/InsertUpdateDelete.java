/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encryption.and.decryption;

import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author ubuntu
 */
public class InsertUpdateDelete {
    public static void setData(String Query,String msg)
    {
        Databaseconnection dc =new Databaseconnection();
    java.sql.Connection con=null;
    Statement st=null;
    
    try
    {
        con=dc.getConnection();
        st=con.createStatement();
        st.executeUpdate(Query);
    if(!msg.equals(""))
    
        JOptionPane.showMessageDialog(null,msg);
    
    }
    catch(Exception e)
    {
        JOptionPane.showMessageDialog(null,e);
        
    }

    }
}
